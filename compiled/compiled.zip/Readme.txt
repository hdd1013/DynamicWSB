DynamicWSB

Usage:
You MUST make the settings folder to be "scriptname"+"Settings", and you also NEED a valid settings.ini inside the folder.
You can change the script/exe filename, but the Settings Folder must be renamed as well in such cases.

License: MIT

I'm kind of procrastinating. I will write this later.